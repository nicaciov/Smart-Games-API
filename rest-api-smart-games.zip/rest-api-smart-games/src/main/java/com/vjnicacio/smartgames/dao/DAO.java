package com.vjnicacio.smartgames.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.vjnicacio.smartgames.model.GameModel;
import com.vjnicacio.smartgames.model.PlatformModel;
import com.vjnicacio.smartgames.model.StoreModel;

public class DAO {

	static String url = "jdbc:mysql://localhost/SMART_GAMES";
	static String usuario = "root";
	static String senha = "123456";

	public static GameModel ObjectGame(ResultSet reader) {

		GameModel gameModel = new GameModel();

		try {
			gameModel.id = reader.getInt("id");
			gameModel.game_name = reader.getString("game_name");
			gameModel.game_description = reader.getString("game_description");
			gameModel.game_price = reader.getString("game_price");

			gameModel.listPlatforms = listAllPlatforms(gameModel.id);
			gameModel.listStores = listAllStores(gameModel.id);

			try {
				String mysqlDateFormat = "dd/MM/yyyy HH:mm:ss";
				gameModel.inclusion_date = new SimpleDateFormat(mysqlDateFormat)
						.parse(reader.getString("inclusion_date"));
				gameModel.edit_date = new SimpleDateFormat(mysqlDateFormat).parse(reader.getString("edit_date"));
			} catch (ParseException ex) {
				String mysqlDateFormat = "yyyy-MM-dd HH:mm:ss";
				gameModel.inclusion_date = new SimpleDateFormat(mysqlDateFormat)
						.parse(reader.getString("inclusion_date"));
				gameModel.edit_date = new SimpleDateFormat(mysqlDateFormat).parse(reader.getString("edit_date"));
			}

			gameModel.photo = reader.getString("photo");
		} catch (Exception e) {
			// TODO: handle exception
		}

		return gameModel;

	}

	public static GameModel ObjectGameNoImage(ResultSet reader) {

		GameModel gameModel = new GameModel();

		try {
			gameModel.id = reader.getInt("id");
			gameModel.game_name = reader.getString("game_name");
			gameModel.game_description = reader.getString("game_description");
			gameModel.game_price = reader.getString("game_price");

		} catch (Exception e) {
			// TODO: handle exception
		}

		return gameModel;

	}

	public static PlatformModel ObjectPlatform(ResultSet reader) {

		PlatformModel platformModel = new PlatformModel();

		try {
			platformModel.id = reader.getInt("id");
			platformModel.game_id = reader.getInt("game_id");
			platformModel.platform = reader.getString("platform");

			try {
				String mysqlDateFormat = "dd/MM/yyyy HH:mm:ss";
				platformModel.inclusion_date = new SimpleDateFormat(mysqlDateFormat)
						.parse(reader.getString("inclusion_date"));
				platformModel.edit_date = new SimpleDateFormat(mysqlDateFormat).parse(reader.getString("edit_date"));
			} catch (ParseException ex) {
				String mysqlDateFormat = "yyyy-MM-dd HH:mm:ss";
				platformModel.inclusion_date = new SimpleDateFormat(mysqlDateFormat)
						.parse(reader.getString("inclusion_date"));
				platformModel.edit_date = new SimpleDateFormat(mysqlDateFormat).parse(reader.getString("edit_date"));
			}
		} catch (Exception e) {
			// TODO: handle exception
		}

		return platformModel;

	}

	public static StoreModel ObjectStore(ResultSet reader) {

		StoreModel storeModel = new StoreModel();

		try {
			storeModel.id = reader.getInt("id");
			storeModel.game_id = reader.getInt("game_id");
			storeModel.store = reader.getString("store");
			storeModel.lat = reader.getString("lat");
			storeModel.lon = reader.getString("lon");

			try {
				String mysqlDateFormat = "dd/MM/yyyy HH:mm:ss";
				storeModel.inclusion_date = new SimpleDateFormat(mysqlDateFormat)
						.parse(reader.getString("inclusion_date"));
				storeModel.edit_date = new SimpleDateFormat(mysqlDateFormat).parse(reader.getString("edit_date"));
			} catch (ParseException ex) {
				String mysqlDateFormat = "yyyy-MM-dd HH:mm:ss";
				storeModel.inclusion_date = new SimpleDateFormat(mysqlDateFormat)
						.parse(reader.getString("inclusion_date"));
				storeModel.edit_date = new SimpleDateFormat(mysqlDateFormat).parse(reader.getString("edit_date"));
			}
		} catch (Exception e) {
			// TODO: handle exception
		}

		return storeModel;

	}

	public static List<GameModel> listAllGames() {

		List<GameModel> list = new ArrayList<GameModel>();

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			try (Connection connection = DriverManager.getConnection(url, usuario, senha)) {
				String sqlQuery = "SELECT g.id, g.game_name, g.game_description, g.game_price, g.inclusion_date, g.edit_date, i.photo FROM games_table AS g INNER JOIN images_table AS i ON g.id = i.game_id;";
				try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);
						ResultSet resultSet = preparedStatement.executeQuery()) {

					while (resultSet.next()) {

						list.add(ObjectGame(resultSet));

					}
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		return list;

	}

	public static GameModel getGame(String id) {

		GameModel gameModel = null;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			try (Connection connection = DriverManager.getConnection(url, usuario, senha)) {
				String sqlQuery = "SELECT g.id, g.game_name, g.game_description, g.game_price, g.inclusion_date, g.edit_date, i.photo FROM games_table AS g INNER JOIN images_table AS i ON g.id = i.game_id WHERE g.id = "
						+ id + ";";
				System.out.println(sqlQuery);
				try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);
						ResultSet resultSet = preparedStatement.executeQuery()) {

					while (resultSet.next()) {

						gameModel = ObjectGameNoImage(resultSet);

					}
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		return gameModel;

	}

	public static List<PlatformModel> listAllPlatforms(long id) {

		List<PlatformModel> list = new ArrayList<PlatformModel>();

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			try (Connection connection = DriverManager.getConnection(url, usuario, senha)) {
				String sqlQuery = "SELECT id, game_id, platform, inclusion_date, edit_date FROM platforms_table WHERE game_id = "
						+ id + ";";
				try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);
						ResultSet resultSet = preparedStatement.executeQuery()) {

					while (resultSet.next()) {

						list.add(ObjectPlatform(resultSet));

					}
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		return list;
	}

	public static List<PlatformModel> getPlatforms(String id) {

		List<PlatformModel> list = new ArrayList<PlatformModel>();

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			try (Connection connection = DriverManager.getConnection(url, usuario, senha)) {
				String sqlQuery = "SELECT id, game_id, platform, inclusion_date, edit_date FROM platforms_table WHERE game_id = "
						+ id + ";";
				try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);
						ResultSet resultSet = preparedStatement.executeQuery()) {

					while (resultSet.next()) {

						list.add(ObjectPlatform(resultSet));

					}
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		return list;

	}

	public static List<StoreModel> listAllStores(long id) {

		List<StoreModel> list = new ArrayList<StoreModel>();

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			try (Connection connection = DriverManager.getConnection(url, usuario, senha)) {
				String sqlQuery = "SELECT s.id, game_id, store, lat, lon, s.inclusion_date, s.edit_date FROM stores_table AS s INNER JOIN place_stores_table AS p ON p.id = s.store_id WHERE game_id = "
						+ id + ";";
				try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);
						ResultSet resultSet = preparedStatement.executeQuery()) {

					while (resultSet.next()) {

						list.add(ObjectStore(resultSet));

					}
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		return list;

	}

	public static List<StoreModel> getStore(String id) {

		List<StoreModel> list = new ArrayList<StoreModel>();

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			try (Connection connection = DriverManager.getConnection(url, usuario, senha)) {
				String sqlQuery = "SELECT s.id, game_id, store, lat, lon, s.inclusion_date, s.edit_date FROM stores_table AS s INNER JOIN place_stores_table AS p ON p.id = s.store_id WHERE game_id = "
						+ id + ";";
				try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery);
						ResultSet resultSet = preparedStatement.executeQuery()) {

					while (resultSet.next()) {

						list.add(ObjectStore(resultSet));

					}
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		return list;

	}

	public static void addCart(String id) {

		List<StoreModel> list = new ArrayList<StoreModel>();

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			try (Connection connection = DriverManager.getConnection(url, usuario, senha)) {
				String sqlQuery = "INSERT INTO shop_cart (game_id, inclusion_date, edit_date) VALUES (?, NOW(), NOW())";

				try (PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery)) {
					preparedStatement.setString(1, id);

					// Executa o INSERT
					int rowsAffected = preparedStatement.executeUpdate();

					if (rowsAffected > 0) {
						System.out.println("Registro inserido com sucesso!");
					} else {
						System.out.println("Falha ao inserir o registro.");
					}
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

}
