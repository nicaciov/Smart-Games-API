package com.vjnicacio.smartgames.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.zip.GZIPOutputStream;
import java.util.zip.GZIPInputStream;

public class CompressionUtils {
 
	public static String compressJSON(String jsonString) throws IOException {
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		try (GZIPOutputStream gzipOutputStream = new GZIPOutputStream(outputStream)) {
			gzipOutputStream.write(jsonString.getBytes("UTF-8"));
		}
		return Base64.getEncoder().encodeToString(outputStream.toByteArray());
	}
 
	public static String decompressJSON(String compressedJson) throws IOException {
		byte[] compressedData = Base64.getDecoder().decode(compressedJson);
		try (ByteArrayInputStream inputStream = new ByteArrayInputStream(compressedData);
				GZIPInputStream gzipInputStream = new GZIPInputStream(inputStream)) {
			byte[] buffer = new byte[1024];
			ByteArrayOutputStream output = new ByteArrayOutputStream();
			int bytesRead;
			while ((bytesRead = gzipInputStream.read(buffer)) > 0) {
				output.write(buffer, 0, bytesRead);
			}
			return new String(output.toByteArray(), "UTF-8");
		}
	}
}
