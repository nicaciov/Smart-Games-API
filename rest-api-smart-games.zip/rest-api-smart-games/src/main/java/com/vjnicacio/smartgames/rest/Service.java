package com.vjnicacio.smartgames.rest;

import java.io.IOException;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.google.gson.Gson;
import com.vjnicacio.smartgames.dao.DAO;
import com.vjnicacio.smartgames.model.GameModel;
import com.vjnicacio.smartgames.model.PlatformModel;
import com.vjnicacio.smartgames.model.StoreModel;
import com.vjnicacio.smartgames.util.CompressionUtils;

@Path("/services")
public class Service {

	private static final String CHARSET_UTF8 = ";charset=utf-8";

	@PostConstruct
	private void init() {

	}

	@GET
	@Path("/info/status")
	@Produces(MediaType.APPLICATION_JSON + CHARSET_UTF8)
	public String statusServico() {
		return "Online";
	}

	@GET
	@Path("/data/listAllGames")
	@Produces(MediaType.APPLICATION_JSON + CHARSET_UTF8)
	public String listAllGames() {

		List<GameModel> list = DAO.listAllGames();

		String retorno = null;
		Gson gson = new Gson();

		retorno = gson.toJson(list);
		return retorno;
	}

	@POST
	@Path("/data/getGame")
	@Produces(MediaType.APPLICATION_JSON + CHARSET_UTF8)
	public String getGame(@FormParam("id") String id) {

		System.out.println(id);

		GameModel gameModel = DAO.getGame(id);

		String retorno = null;
		Gson gson = new Gson();

		retorno = gson.toJson(gameModel);

		return retorno;
	}

	@POST
	@Path("/data/getPlatform")
	@Produces(MediaType.APPLICATION_JSON + CHARSET_UTF8)
	public String getPlatform(@FormParam("id") String id) {

		System.out.println("getPlatform");
		System.out.println(id);

		List<PlatformModel> list = DAO.getPlatforms(id);

		String retorno = null;
		Gson gson = new Gson();

		retorno = gson.toJson(list);

		return retorno;
	}

	@POST
	@Path("/data/getStore")
	@Produces(MediaType.APPLICATION_JSON + CHARSET_UTF8)
	public String getStore(@FormParam("id") String id) {

		System.out.println("getStore");
		System.out.println(id);

		List<StoreModel> list = DAO.getStore(id);

		String retorno = null;
		Gson gson = new Gson();

		retorno = gson.toJson(list);

		return retorno;
	}

	@POST
	@Path("/data/addCart")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.APPLICATION_JSON + CHARSET_UTF8)
	public void addCart(@FormParam("id") String id) {

		DAO.addCart(id);

	}

}
